<?php
class DB extends DBmysql {
   public $dbhost     = 'localhost';
   public $dbuser     = 'root';
   public $dbpassword = '';
   public $dbdefault  = 'glpitest0723';
}
