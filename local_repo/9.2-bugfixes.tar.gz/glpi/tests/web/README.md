Unit tests that require a running webserver
