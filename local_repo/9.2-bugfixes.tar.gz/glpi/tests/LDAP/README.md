Unit tests that require a runing LDAP server
